package org.sda;

import lombok.Data;

@Data
public class Location {
    private IssPosition iss_position;

}