package org.sda;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;
@Data
@AllArgsConstructor
//@Getter
//@Setter
public class IssPosition {
    private double latitude;
    private double longitude;


}
