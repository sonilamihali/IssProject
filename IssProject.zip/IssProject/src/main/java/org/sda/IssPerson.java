package org.sda;

import lombok.Data;

@Data
public class IssPerson {
    private String name;
    private String craft;

}
