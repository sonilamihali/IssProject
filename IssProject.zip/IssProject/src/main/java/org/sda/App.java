package org.sda;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args ) {
//      Menu menu = new Menu();
//      menu.startUp();
      new Menu().startUp();
    }
}
