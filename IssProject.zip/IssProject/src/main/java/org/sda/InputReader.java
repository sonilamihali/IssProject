package org.sda;

import java.util.Scanner;

public class InputReader {
   private Scanner scanner= new Scanner(System.in);
    public  int readInput(){
        return scanner.nextInt();
    }

}
